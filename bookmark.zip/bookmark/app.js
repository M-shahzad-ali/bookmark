
console.log("hijjj")



class collectData{
    constructor(webname,weburl){
        this.webname=webname;
        this.weburl=weburl;
    }

}


class showdaata{

 static objdata(){
    var data=[
            {
            webname:"google",
            weburl:"https://www.google.com"
            },
            {
            webname:"facebook",
            weburl:"https://facebook.com"
            }
]
console.log(data)
  data.forEach(e=>showdaata.collectdata(e))
 }
 static collectdata(e){
    let parentContainer = document.getElementById("content_box");

    let row =document.createElement("div");

    row.setAttribute("class","row");

    row.innerHTML = `
    <div class="col-sm-8">
    <p>${e.webname}</p>

 </div>
 <div class="col-sm-4">
     <button type="button" class="btn btn-outline-primary"><a href="${e.weburl}" >visit</a></button>
     <button type="button" class="btn btn-outline-danger delete">Delete</button>
 </div>
    `

parentContainer.appendChild(row)    
 }
 static DeleteItem(e){
    if(e.target.classList.contains("delete")){ 
    
    e.target.parentElement.parentElement.remove();
       
    }
    
 }

 static formreovelem(){
    let websitename = document.getElementById("website_name").value="";
    let websiteurl = document.getElementById("website_url").value="";
 }
 static formvalueget(){
    
    let websiteformname = document.getElementById("website_name").value;
    let websiteformurl = document.getElementById("website_url").value;
    var getvalue = [websiteformname,websiteformurl];
    return getvalue;

 }
 
}

showdaata.objdata();
document.querySelectorAll("#content_box .btn").forEach(e=>{
    e.addEventListener("click",(j)=>{
  
        showdaata.DeleteItem(j)
    
    
    })
})